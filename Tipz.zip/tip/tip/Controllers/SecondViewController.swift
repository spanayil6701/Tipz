//
//  SecondViewController.swift
//  tip
//
//  Created by Sachin Panayil on 11/22/20.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var totalTextField: UITextField!
    @IBOutlet weak var peopleInPartyLabel: UILabel!
    @IBOutlet weak var partyStepper: UIStepper!
    @IBOutlet weak var totalLabel: UILabel!
    
    override func viewDidLoad() {
        
    }
    
    @IBAction func stepper(_ sender: UIStepper) {
        
        peopleInPartyLabel.text = String(Int(partyStepper.value))
        
    }
    
    @IBAction func calculatePressed(_ sender: UIButton) {
        
        let total = Double(totalTextField.text ?? "0")
        let total2 = Double(peopleInPartyLabel.text ?? "0")
        
        let finalTotal = total! / total2!
        
        totalLabel.text = String(format: "$%.2f", finalTotal)
        
    }
    
}
