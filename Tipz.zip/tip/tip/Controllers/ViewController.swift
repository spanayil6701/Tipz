//
//  ViewController.swift
//  tip
//
//  Created by Sachin Panayil on 11/22/20.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var totalAmountTextField: UITextField!
    @IBOutlet weak var percentageLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tipSlider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func percentageSlider(_ sender: UISlider) {
        
        let percent = String(Int(sender.value * 100))
        percentageLabel.text = "\(percent)%"
        
    }
    
    @IBAction func calculatePressed(_ sender: UIButton) {
        
        let originalAmount = Double(totalAmountTextField.text ?? "0")
        let tip = originalAmount! * Double(tipSlider.value)
        let total = originalAmount! + tip
        
        totalLabel.text = String(format: "$%.2f", total)
        
    }

}


